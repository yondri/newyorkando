=== Foobar Notification Bars ===
Requires at least: 3.1
Tested up to: 3.2

Show awesome looking notification bars on specific pages. Set a default to be shown on all pages.

Installation
-------------
1) Copy or upload the entire zip that was downloaded to your server
2) Browse to your site's plugin page in the WordPress admin
3) Find the Foobar plugin in the list and activate it
4) Click the new Foobar menu item to add and manage your site's Foobars

Documentation
-------------
Under settings, click "foobar settings", then you will find a link to the documentation.