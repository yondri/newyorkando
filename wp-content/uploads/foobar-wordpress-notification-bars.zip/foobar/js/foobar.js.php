<?php
global $foobar_js;
header( 'Content-Type: text/javascript' );
?>
<?php echo $foobar_js; ?>