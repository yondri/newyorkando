<?php
global $foobar_admin_js;
header( 'Content-Type: text/javascript' );
?>
<?php echo $foobar_admin_js; ?>