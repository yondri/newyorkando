<?php
global $foobar_css;
header( 'Content-Type: text/css' );
?>
<?php echo $foobar_css; ?>